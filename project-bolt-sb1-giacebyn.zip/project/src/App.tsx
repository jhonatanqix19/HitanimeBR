import React, { useState, useEffect } from 'react';
import { questions } from './data/quizData';
import { QuizState, UserAnswer } from './types/quiz';
import { calculateDominantStyle, calculateDiscount } from './utils/quizUtils';
import QuizIntro from './components/QuizIntro';
import QuizQuestion from './components/QuizQuestion';
import QuizResults from './components/QuizResults';
import CoinCounter from './components/CoinCounter';
import Background from './components/Background';

function App() {
  const [started, setStarted] = useState(false);
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    answers: [],
    totalCoins: 0,
    quizCompleted: false
  });
  const [gainedCoins, setGainedCoins] = useState<number | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);

  useEffect(() => {
    if (!started) {
      setProgressPercent(0);
    } else if (quizState.quizCompleted) {
      setProgressPercent(100);
    } else {
      const progress = (quizState.currentQuestionIndex / questions.length) * 100;
      setProgressPercent(progress);
    }
  }, [started, quizState.currentQuestionIndex, quizState.quizCompleted]);

  const startQuiz = () => {
    setStarted(true);
  };

  const handleAnswerSelected = (answer: UserAnswer, coins: number) => {
    const newAnswers = [...quizState.answers, answer];
    const newTotalCoins = quizState.totalCoins + coins;
    
    setGainedCoins(coins);
    setTimeout(() => setGainedCoins(null), 1000);
    
    const nextIndex = quizState.currentQuestionIndex + 1;
    if (nextIndex < questions.length) {
      setQuizState({
        ...quizState,
        currentQuestionIndex: nextIndex,
        answers: newAnswers,
        totalCoins: newTotalCoins
      });
    } else {
      const dominantStyle = calculateDominantStyle(newAnswers);
      const discountPercentage = calculateDiscount(newTotalCoins);
      
      setQuizState({
        ...quizState,
        answers: newAnswers,
        totalCoins: newTotalCoins,
        quizCompleted: true,
        dominantStyle,
        discountPercentage
      });
    }
  };

  const renderContent = () => {
    if (!started) {
      return <QuizIntro onStart={startQuiz} />;
    }
    
    if (quizState.quizCompleted && quizState.dominantStyle && quizState.discountPercentage) {
      return (
        <QuizResults 
          totalCoins={quizState.totalCoins}
          dominantStyle={quizState.dominantStyle}
          discountPercentage={quizState.discountPercentage}
        />
      );
    }
    
    const currentQuestion = questions[quizState.currentQuestionIndex];
    return (
      <QuizQuestion
        question={currentQuestion}
        onAnswerSelected={handleAnswerSelected}
      />
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 overflow-hidden relative">
      <Background quizProgress={progressPercent} />
      
      {started && (
        <CoinCounter totalCoins={quizState.totalCoins} gainedCoins={gainedCoins} />
      )}
      
      <div className="w-full max-w-4xl z-10 py-10">
        {renderContent()}
      </div>
    </div>
  );
}

export default App;