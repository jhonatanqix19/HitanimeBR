import { UserAnswer, Style } from '../types/quiz';

export const calculateDominantStyle = (answers: UserAnswer[]): Style => {
  const styleCounts: Record<Style, number> = {
    rima: 0,
    melodia: 0,
    estrategia: 0,
    caosCriativo: 0
  };
  
  answers.forEach(answer => {
    styleCounts[answer.selectedOption.style]++;
  });
  
  let maxCount = 0;
  let dominantStyle: Style = 'melodia'; // Default
  
  Object.entries(styleCounts).forEach(([style, count]) => {
    if (count > maxCount) {
      maxCount = count;
      dominantStyle = style as Style;
    }
  });
  
  return dominantStyle;
};

export const calculateDiscount = (totalCoins: number): number => {
  if (totalCoins >= 81) return 15;
  if (totalCoins >= 41) return 10;
  return 5;
};

export const calculateTotalCoins = (answers: UserAnswer[]): number => {
  return answers.reduce((total, answer) => total + answer.selectedOption.coins, 0);
};