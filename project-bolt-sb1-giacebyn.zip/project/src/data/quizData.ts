import { Question, Result } from '../types/quiz';

export const questions: Question[] = [
  {
    id: 1,
    text: "Qual será sua arma musical?",
    options: [
      { 
        id: "1-1", 
        text: "Microfone encantado", 
        emoji: "🎤", 
        coins: 20, 
        style: "rima" 
      },
      { 
        id: "1-2", 
        text: "Fones de ouvido lendários", 
        emoji: "🎧", 
        coins: 15, 
        style: "melodia" 
      },
      { 
        id: "1-3", 
        text: "Caderno de letras infinitas", 
        emoji: "📝", 
        coins: 10, 
        style: "estrategia" 
      },
      { 
        id: "1-4", 
        text: "Caixa de som portátil", 
        emoji: "📦", 
        coins: 5, 
        style: "caosCriativo" 
      }
    ]
  },
  {
    id: 2,
    text: "Qual seu elemento sonoro?",
    options: [
      { 
        id: "2-1", 
        text: "Flow do Fogo", 
        emoji: "🔥", 
        coins: 20, 
        style: "rima" 
      },
      { 
        id: "2-2", 
        text: "Melodia da Água", 
        emoji: "🌊", 
        coins: 15, 
        style: "melodia" 
      },
      { 
        id: "2-3", 
        text: "Improviso do Vento", 
        emoji: "🌪️", 
        coins: 10, 
        style: "caosCriativo" 
      },
      { 
        id: "2-4", 
        text: "Ritmo da Terra", 
        emoji: "🧱", 
        coins: 5, 
        style: "estrategia" 
      }
    ]
  },
  {
    id: 3,
    text: "Qual treino você escolhe com o Mestre Musical?",
    options: [
      { 
        id: "3-1", 
        text: "Harmonia Divina", 
        emoji: "🎼", 
        coins: 20, 
        style: "melodia" 
      },
      { 
        id: "3-2", 
        text: "Beat de Outra Dimensão", 
        emoji: "🎹", 
        coins: 15, 
        style: "estrategia" 
      },
      { 
        id: "3-3", 
        text: "Treino de Percussão Brutal", 
        emoji: "🥁", 
        coins: 10, 
        style: "caosCriativo" 
      },
      { 
        id: "3-4", 
        text: "Teste de Rima Imediata", 
        emoji: "🎲", 
        coins: 20, 
        style: "rima" 
      }
    ]
  },
  {
    id: 4,
    text: "Qual missão você aceita primeiro?",
    options: [
      { 
        id: "4-1", 
        text: "Viralizar um hit no TikTok", 
        emoji: "🏆", 
        coins: 20, 
        style: "caosCriativo" 
      },
      { 
        id: "4-2", 
        text: "Criar trilha sonora de anime", 
        emoji: "🎬", 
        coins: 15, 
        style: "melodia" 
      },
      { 
        id: "4-3", 
        text: "Produzir uma faixa original", 
        emoji: "🎧", 
        coins: 10, 
        style: "estrategia" 
      },
      { 
        id: "4-4", 
        text: "Enfrentar um vilão rimador", 
        emoji: "🎤", 
        coins: 20, 
        style: "rima" 
      }
    ]
  },
  {
    id: 5,
    text: "Seu estilo no mundo musical é...",
    options: [
      { 
        id: "5-1", 
        text: "Direto, impactante e cheio de flow", 
        emoji: "🔊", 
        coins: 15, 
        style: "rima" 
      },
      { 
        id: "5-2", 
        text: "Emocionante e melódico", 
        emoji: "🎶", 
        coins: 15, 
        style: "melodia" 
      },
      { 
        id: "5-3", 
        text: "Calculado e técnico", 
        emoji: "🧩", 
        coins: 15, 
        style: "estrategia" 
      },
      { 
        id: "5-4", 
        text: "Improvisado e aleatório", 
        emoji: "🤪", 
        coins: 15, 
        style: "caosCriativo" 
      }
    ]
  }
];

export const results: Record<string, Result> = {
  rima: {
    title: "MC da Lenda Ancestral",
    description: "Você é o MC da Lenda Ancestral! Seu flow é tão forte que derrota até vilões. Liberte esse poder com seu desconto místico no curso Hit Anime.",
    style: "rima"
  },
  melodia: {
    title: "Maestro Dimensional",
    description: "Você cria atmosferas como um mestre da melodia. Com suas Moedas Otaku, você recebe um bônus musical para começar no Hit Anime.",
    style: "melodia"
  },
  estrategia: {
    title: "Gênio Tático do Estúdio",
    description: "Você transforma ideias em hits com precisão. Seu bônus de Moedas Otaku, com desconto garantido no Hit Anime.",
    style: "estrategia"
  },
  caosCriativo: {
    title: "Artista do Caos Criativo",
    description: "Você quebra regras e vira tendência! Use suas Moedas Otaku para desbloquear seu desconto e começar sua jornada no Hit Anime.",
    style: "caosCriativo"
  }
};

export const COURSE_URL = "https://pay.cakto.com.br/hqsm4ih_358494";