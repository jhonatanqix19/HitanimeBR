export type Style = 'rima' | 'melodia' | 'estrategia' | 'caosCriativo';

export interface Option {
  id: string;
  text: string;
  emoji: string;
  coins: number;
  style: Style;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
}

export interface UserAnswer {
  questionId: number;
  selectedOption: Option;
}

export interface Result {
  title: string;
  description: string;
  style: Style;
}

export interface QuizState {
  currentQuestionIndex: number;
  answers: UserAnswer[];
  totalCoins: number;
  quizCompleted: boolean;
  dominantStyle?: Style;
  discountPercentage?: number;
}