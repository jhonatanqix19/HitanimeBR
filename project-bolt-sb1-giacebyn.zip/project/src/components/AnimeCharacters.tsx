import React from 'react';

interface AnimeCharactersProps {
  position: 'left' | 'right';
  gender: 'male' | 'female';
}

const AnimeCharacters: React.FC<AnimeCharactersProps> = ({ position, gender }) => {
  const imageUrl = gender === 'male' 
    ? 'https://images.pexels.com/photos/5486756/pexels-photo-5486756.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    : 'https://images.pexels.com/photos/9638689/pexels-photo-9638689.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1';
  
  return (
    <div 
      className={`
        fixed bottom-0 ${position === 'left' ? 'left-0' : 'right-0'}
        w-28 h-48 md:w-40 md:h-64 lg:w-48 lg:h-80
        z-10 pointer-events-none
        transition-all duration-500 ease-in-out
        opacity-75 hover:opacity-100
      `}
    >
      <img 
        src={imageUrl} 
        alt={`Anime ${gender} character`} 
        className="w-full h-full object-contain object-bottom"
      />
    </div>
  );
};

export default AnimeCharacters;