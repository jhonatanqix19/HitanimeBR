import React from 'react';

interface BackgroundProps {
  quizProgress: number;
}

const Background: React.FC<BackgroundProps> = ({ quizProgress }) => {
  // Generate dynamic background based on quiz progress (0-100)
  const getGradient = () => {
    if (quizProgress < 20) {
      return 'from-indigo-900 via-purple-900 to-violet-800'; // Start
    } else if (quizProgress < 40) {
      return 'from-purple-900 via-pink-800 to-violet-900'; // Q1-Q2
    } else if (quizProgress < 60) {
      return 'from-blue-900 via-indigo-800 to-purple-900'; // Q2-Q3
    } else if (quizProgress < 80) {
      return 'from-violet-900 via-purple-800 to-fuchsia-900'; // Q3-Q4
    } else if (quizProgress < 100) {
      return 'from-fuchsia-900 via-purple-800 to-pink-900'; // Q5
    } else {
      return 'from-pink-900 via-purple-900 to-indigo-900'; // Results
    }
  };

  return (
    <div 
      className={`fixed inset-0 w-full h-full bg-gradient-to-br ${getGradient()} transition-colors duration-1000 ease-in-out -z-10`}
    >
      {/* Add animated particles or stars */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="stars-1"></div>
        <div className="stars-2"></div>
        <div className="stars-3"></div>
      </div>
    </div>
  );
};

export default Background;