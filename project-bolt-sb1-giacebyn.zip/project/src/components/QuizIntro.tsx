import React from 'react';

interface QuizIntroProps {
  onStart: () => void;
}

const QuizIntro: React.FC<QuizIntroProps> = ({ onStart }) => {
  return (
    <div className="max-w-2xl mx-auto p-8 bg-gradient-to-br from-purple-900/80 to-indigo-900/80 rounded-2xl shadow-2xl border-2 border-purple-500 text-center">
      <h1 className="text-4xl md:text-5xl font-bold mb-2 text-white">
        HIT ANIMEBR
      </h1>
      <h2 className="text-2xl md:text-3xl font-bold mb-6 text-purple-200">
        Qual Seu Poder Musical em Otaku?
      </h2>
      
      <div className="mb-8 text-purple-100">
        <p className="text-xl mb-4">🌀 Você foi invocado para o mundo de Otaku — um universo onde o talento musical é a força suprema.</p>
        <p className="mb-4">Para sobreviver e vencer, você precisa montar sua build musical com sabedoria, escolhendo suas armas, elementos e estratégias.</p>
        <p className="font-bold">Cada decisão vai te dar Moedas Otaku, e no final você descobrirá:</p>
        
        <ul className="list-disc list-inside text-left mt-4 space-y-2">
          <li>Qual é sua <span className="font-bold text-yellow-300">Classe Musical</span></li>
          <li>Quantas <span className="font-bold text-yellow-300">Moedas Otaku</span> você acumulou</li>
          <li>Um <span className="font-bold text-yellow-300">desconto mágico</span> proporcional para desbloquear o curso Hit Anime</li>
        </ul>
      </div>
      
      <button 
        onClick={onStart}
        className="px-8 py-4 bg-gradient-to-r from-pink-500 to-red-600 text-white font-bold text-xl rounded-full shadow-lg hover:shadow-xl transform transition-all duration-300 hover:scale-105"
      >
        ⚔️ Iniciar Aventura Musical
      </button>
    </div>
  );
};

export default QuizIntro;