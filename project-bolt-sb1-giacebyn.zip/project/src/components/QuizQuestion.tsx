import React, { useState } from 'react';
import { Question, Option, UserAnswer } from '../types/quiz';
import QuizOption from './QuizOption';

interface QuizQuestionProps {
  question: Question;
  onAnswerSelected: (answer: UserAnswer, coins: number) => void;
}

const QuizQuestion: React.FC<QuizQuestionProps> = ({ question, onAnswerSelected }) => {
  const [answered, setAnswered] = useState(false);
  
  const handleOptionClick = (option: Option) => {
    if (answered) return;
    
    setAnswered(true);
    onAnswerSelected({
      questionId: question.id,
      selectedOption: option
    }, option.coins);
    
    // Reset for next question after a delay
    setTimeout(() => {
      setAnswered(false);
    }, 500);
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6">
      <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center text-white drop-shadow-lg">
        {question.id}️⃣ {question.text}
      </h2>
      
      <div className="space-y-4 mt-8">
        {question.options.map((option) => (
          <QuizOption
            key={option.id}
            option={option}
            onClick={handleOptionClick}
            isDisabled={answered}
          />
        ))}
      </div>
    </div>
  );
};

export default QuizQuestion;