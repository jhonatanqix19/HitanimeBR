import React from 'react';
import { Option } from '../types/quiz';

interface QuizOptionProps {
  option: Option;
  onClick: (option: Option) => void;
  isDisabled: boolean;
}

const QuizOption: React.FC<QuizOptionProps> = ({ option, onClick, isDisabled }) => {
  return (
    <button
      onClick={() => onClick(option)}
      disabled={isDisabled}
      className={`
        w-full py-4 px-6 mb-3 rounded-lg shadow-md 
        flex items-center gap-3 transition-all duration-300
        ${isDisabled 
          ? 'opacity-50 cursor-not-allowed' 
          : 'hover:scale-102 hover:shadow-lg transform'
        }
        bg-gradient-to-r from-indigo-500 to-purple-600 text-white
        border-2 border-purple-300 hover:border-white
      `}
    >
      <span className="text-2xl">{option.emoji}</span>
      <span className="text-left text-lg font-medium flex-1">{option.text}</span>
      <span className="bg-yellow-400 text-yellow-900 font-bold rounded-full px-3 py-1 text-sm flex items-center">
        🪙 {option.coins}
      </span>
    </button>
  );
};

export default QuizOption;