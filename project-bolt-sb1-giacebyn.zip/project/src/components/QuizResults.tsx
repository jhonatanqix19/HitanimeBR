import React, { useEffect, useState } from 'react';
import { Result, Style } from '../types/quiz';
import { results, COURSE_URL } from '../data/quizData';
import { ArrowRight } from 'lucide-react';

interface QuizResultsProps {
  totalCoins: number;
  dominantStyle: Style;
  discountPercentage: number;
}

const QuizResults: React.FC<QuizResultsProps> = ({ 
  totalCoins, 
  dominantStyle, 
  discountPercentage 
}) => {
  const result = results[dominantStyle];
  const [visible, setVisible] = useState(false);
  
  useEffect(() => {
    // Animation timing
    setTimeout(() => setVisible(true), 500);
  }, []);
  
  return (
    <div className={`
      max-w-2xl mx-auto p-8 
      bg-gradient-to-br from-purple-900/80 to-indigo-900/80 
      rounded-2xl shadow-2xl border-2 border-purple-500 
      text-center transition-all duration-1000
      ${visible ? 'opacity-100 transform-none' : 'opacity-0 translate-y-10'}
    `}>
      <div className="text-6xl mb-4">✨</div>
      
      <h2 className="text-3xl md:text-4xl font-bold mb-3 text-white">
        {result.title}
      </h2>
      
      <p className="text-xl mb-6 text-purple-100">
        {result.description.replace("[X]", totalCoins.toString()).replace("[5/10/15]", discountPercentage.toString())}
      </p>
      
      <div className="flex flex-col items-center mb-8">
        <div className="py-3 px-8 bg-yellow-400 text-yellow-900 font-bold text-2xl rounded-lg mb-4">
          🪙 {totalCoins} Moedas Otaku
        </div>
        
        <div className="py-3 px-8 bg-green-500 text-white font-bold text-2xl rounded-lg">
          🎁 {discountPercentage}% de Desconto
        </div>
      </div>
      
      <a 
        href={COURSE_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-pink-500 to-red-600 text-white font-bold text-xl rounded-full shadow-lg hover:shadow-xl transform transition-all duration-300 hover:scale-105"
      >
        🔥 Desbloquear meu Poder Musical e Começar Agora
        <ArrowRight className="ml-2" />
      </a>
    </div>
  );
};

export default QuizResults;