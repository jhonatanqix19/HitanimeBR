import React, { useEffect, useState } from 'react';
import { PlusCircle } from 'lucide-react';

interface CoinCounterProps {
  totalCoins: number;
  gainedCoins: number | null;
}

const CoinCounter: React.FC<CoinCounterProps> = ({ totalCoins, gainedCoins }) => {
  const [isAnimating, setIsAnimating] = useState(false);
  
  useEffect(() => {
    if (gainedCoins) {
      setIsAnimating(true);
      const timer = setTimeout(() => setIsAnimating(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [gainedCoins]);

  return (
    <div className="fixed top-5 right-5 z-50">
      <div className="flex items-center gap-2 bg-yellow-400/90 backdrop-blur-sm text-yellow-900 font-bold px-4 py-2 rounded-full shadow-lg">
        <img 
          src="/otaku-coin.png" 
          alt="Moeda Otaku"
          className="w-8 h-8 object-contain"
        />
        <span className="text-lg">{totalCoins}</span>
        
        {gainedCoins && isAnimating && (
          <div className="absolute -bottom-8 right-2 flex items-center text-yellow-500 font-bold animate-bounce">
            <PlusCircle size={16} className="mr-1" />
            <span>{gainedCoins}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default CoinCounter;